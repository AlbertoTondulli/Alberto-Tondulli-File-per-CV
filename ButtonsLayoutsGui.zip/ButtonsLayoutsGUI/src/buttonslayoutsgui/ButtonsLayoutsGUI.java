/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package buttonslayoutsgui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class ButtonsLayoutsGUI {

    public static void main(String[] args) {
        // TODO code application logic
        // FRAMES
        // first frame
        JFrame f = new JFrame("Finestra");
        f.setSize(1000, 900);
        f.setDefaultCloseOperation(2);
        // second frame
        JFrame f2 = new JFrame("Finestra2");
        f2.setSize(1000, 900);
        f2.setDefaultCloseOperation(2);
        // third frame
        JFrame f3 = new JFrame("Finestra3");
        f3.setSize(1000, 900);
        f3.setDefaultCloseOperation(2);

        // LAYOUTS
        // frame 1 layout
        FlowLayout l = new FlowLayout(1);
        f.setLayout(l);
        // frame 2 layout
        BorderLayout l2 = new BorderLayout(1000, 1000);
        f2.setLayout(l2);
        // frame 3 layout
        GridLayout l3 = new GridLayout(3, 1);
        f3.setLayout(l3);

        // BUTTONS
        // frame 1 buttons
        JButton b = new JButton("Bottone 1");
        JButton b2 = new JButton("Bottone 2");
        JButton b3 = new JButton("Bottone 3");
        f.add(b);
        f.add(b2);
        f.add(b3);
        // frame 2 buttons
        JButton b21 = new JButton("Bottone 1");
        JButton b22 = new JButton("Bottone 2");
        JButton b23 = new JButton("Bottone 3");
        f2.add(b21, BorderLayout.SOUTH);
        f2.add(b22, BorderLayout.NORTH);
        f2.add(b23, BorderLayout.CENTER);
        // frame 3 buttons
        JButton b31 = new JButton("Bottone 1");
        JButton b32 = new JButton("Bottone 2");
        JButton b33 = new JButton("Bottone 3");
        f3.add(b31);
        f3.add(b32);
        f3.add(b33);

        // VISIBILITY
        f.setVisible(true);
        f2.setVisible(true);
        f3.setVisible(true);
    }
}