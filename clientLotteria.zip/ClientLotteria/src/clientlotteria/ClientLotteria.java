package clientlotteria;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientLotteria {

    
    public static void main(String[] args) {
       int num[] = new int[5];
       int numV[] = new int[5];
        try {
            Socket s = new Socket("localhost",8080);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            System.out.println("I miei numeri");
            for (int i=0; i<5; i++){
                num[i]=Integer.parseInt(in.readLine());
                System.out.println(num[i]);
            }
            System.out.println("I numeri vincenti");
            for (int i=0; i<5; i++){
                numV[i]=Integer.parseInt(in.readLine());
                System.out.println(numV[i]);
            }
            int count=0;
            for (int i=0; i<5; i++){
                for (int j=0; j<5; j++){
                    if (numV[i]==num[j]){
                        count++;
                    }
                }
            }
            
            out.println("Ho trovato "+count+" numeri!");
            
        } catch (IOException ex) {
            System.getLogger(ClientLotteria.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        
    }
    
}
