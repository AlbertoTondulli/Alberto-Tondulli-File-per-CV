package serverlotteria;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

public class ServerLotteria {

    public static void main(String[] args) {
       
        try {
            ServerSocket sc = new ServerSocket(8080);
            Socket s;
            NumVincenti nv = new NumVincenti();
            for (int i=0; i<4; i++){
                s=sc.accept();
                ThreadLotteria tl = new ThreadLotteria(s,nv,i+1);
                tl.start();
            }
            Random r = new Random();
            for (int i=0; i<5; i++){
                nv.numV[i]=r.nextInt(90)+1;
            }
            
            nv.pronto=true;
            
        } catch (IOException ex) {
            System.getLogger(ServerLotteria.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        
        
    }
    
}
