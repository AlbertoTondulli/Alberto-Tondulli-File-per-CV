
package serverlotteria;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;


public class ThreadLotteria extends Thread{
    
    Socket s;
    NumVincenti nv;
    int p;

    public ThreadLotteria(Socket s, NumVincenti nv, int p) {
        this.s = s;
        this.nv = nv;
        this.p = p;
    }
        
    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            Random r = new Random();
            for (int i=0;i<5;i++){
                int num=r.nextInt(90)+1;
                out.println(num+"");
            }
            
            while (nv.pronto == false){
                try {
                    sleep(500);
                } catch (InterruptedException ex) {
                    System.getLogger(ThreadLotteria.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
                }
            }
            
            for (int i=0;i<5;i++){
                out.println(nv.numV[i]+"");
            }
            
            String s = in.readLine();
            System.out.println("Giocatore "+p+": "+s);
            
        }catch (IOException e){
            System.out.println("Errore");
        }
            
    }
}
