package serverlotteria;

public class NumVincenti {
    
    int numV[] = new int[5];
    boolean pronto = false;
    
}
