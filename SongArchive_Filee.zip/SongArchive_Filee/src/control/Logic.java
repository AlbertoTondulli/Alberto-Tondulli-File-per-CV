/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import model.Archive;
import model.Song;
import view.ActionPanel;
import view.MainWin;
import view.SongPanel;

/**
 *
 * @author Tondu
 */
public class Logic implements ActionListener{

    private Archive songList;
    private int cursor;
    private SongPanel sp;
    MainWin win;

    
    public Logic() {
        
        
    }
    
    public void start(Archive songList){
        this.songList = songList;
        this.cursor = 0;
        this.win = new MainWin(this);
        update();
        
        
        win.setVisible(true);
        
    }
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        switch(cmd){
            case ActionPanel.NEW:
                Song added = win.getData();
                if (added != null){
                    songList.add(added);
                    cursor = songList.size() -1;
                    update();
                }else{
                    System.out.println("ERRORE DATI NON VALIDI");
                }
                
                break;
            case ActionPanel.NEXT:
                if((cursor + 1) < songList.size()){
                    cursor++;
                    update();
                }else{
                    System.out.println("ERRORE ARRAY ARRIVATO ALLA FINE");
                }
                break;
            case ActionPanel.PREV:
                if(cursor != 0){
                    cursor --;
                    update();
                }else{
                    System.out.println("ERRORE HAI RAGGIUNTO L'INIZIO DELL'ARRAY");
                }
                break;
            }
        
    
    }
    
    public void update(){
        win.setData(songList.get(cursor));
    }
}
