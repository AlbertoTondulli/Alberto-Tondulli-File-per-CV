/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Tondu
 */
public class ActionPanel extends JPanel{
    public static final String NEW = "new";
    public static final String NEXT = "next";
    public static final String PREV = "prev";
    

    public ActionPanel(ActionListener al) {
        
        super(new FlowLayout());
        
        newButton("<<", PREV, al);
        newButton("nuovo", NEW, al);
        newButton(">>", NEXT, al);
        
    }
    
    private void newButton(String txt, String cmd, ActionListener al){
        JButton b = new JButton(txt);
        b.addActionListener(al);
        b.setActionCommand(cmd);
        this.add(b);
        
    }
    
}
