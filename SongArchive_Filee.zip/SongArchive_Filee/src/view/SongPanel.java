/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.Song;
import model.Time;

/**
 *
 * @author Tondu
 */
public class SongPanel extends JPanel {
    private Song data;
    
    private JTextField titleField;
    private JTextField yearField;
    private JTextField minField;
    private JTextField secField;
    
    public SongPanel() {
        super(new GridLayout(2, 4));
        
       
        this.titleField = new JTextField();
        this.yearField = new JTextField();
        this.minField = new JTextField();
        this.secField = new JTextField();
        
        this.add(new JLabel("Titolo"));
        this.add(this.titleField);
        this.add(new JLabel("Anno"));
        this.add(this.yearField);
        this.add(new JLabel("Min"));
        this.add(this.minField);
        this.add(new JLabel("sec"));
        this.add(this.secField);
        
        
    }
    
    public void setData(Song data) {
        this.data = data;
        
        this.titleField.setText(data.getTitle());
        this.yearField.setText("" + data.getYear());
        this.minField.setText("" + data.getTime().getMin());
        this.secField.setText("" + data.getTime().getSec());
    }
    
    public Song getData() {
        Song out;
        String title = this.titleField.getText();
        int year = Integer.parseInt(this.yearField.getText());
        int min = Integer.parseInt(this.minField.getText());
        int sec = Integer.parseInt(this.secField.getText());
        
        Time time = new Time(min, sec);
        
        out = new Song(title, year, time);
        return out;
    }

}