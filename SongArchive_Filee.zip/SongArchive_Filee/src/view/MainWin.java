/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import control.Logic;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import model.Archive;
import model.Song;


/**
 *
 * @author Tondu
 */
public class MainWin extends MyFrame{
    
    Archive songList;
    private SongPanel sp;
    private ActionPanel ap;
    private Logic logic;
    
    public MainWin(ActionListener al) {
        super("canzoni", 300, 150);
        this.setLayout(new BorderLayout());
        
        
        
        
        sp = new SongPanel();
        this.add(sp, BorderLayout.CENTER);
        ap = new ActionPanel(al);
        this.add(ap, BorderLayout.SOUTH);
        
    }

    public void setData(Song data) {
        sp.setData(data);
    }

    public Song getData() {
        return sp.getData();
    }
    
    

    
    }
    

