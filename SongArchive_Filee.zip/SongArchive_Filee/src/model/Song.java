/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author Tondu
 */
public class Song implements Serializable{
    
    private final String title;
    private final int year;
    private final Time time;

    public Song(String title, int year, Time time) {
        this.title = title;
        this.year = year;
        this.time = time;
    }

    /**
     * Get the value of time
     *
     * @return the value of time
     */
    public Time getTime() {
        return time;
    }

    /**
     * Get the value of year
     *
     * @return the value of year
     */
    public int getYear() {
        return year;
    }


    /**
     * Get the value of Title
     *
     * @return the value of Title
     */
    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return "Song{" + "title=" + title + ", year=" + year + ", time=" + time + '}';
    }


}
