/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author Tondu
 */
public class Time implements Serializable{
    
    private final int min;
    
    private final int sec;

    public Time(int min, int sec) {
        this.min = min;
        this.sec = sec;
    }
    
    

    /**
     * Get the value of sec
     *
     * @return the value of sec
     */
    public int getSec() {
        return sec;
    }


    /**
     * Get the value of min
     *
     * @return the value of min
     */
    public int getMin() {
        return min;
    }

    @Override
    public String toString() {
    return min + ":" + sec;
}
}
