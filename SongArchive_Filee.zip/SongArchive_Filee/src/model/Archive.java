/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Tondu
 */
public class Archive extends ArrayList<Song> implements Serializable{
    
    
    private static final String FILE_NAME = "songArchive.dat";
    
    /**
     * Salva l'archivio di canzoni su file
     * @param archive L'archivio da salvare
     */
    public static void save(Archive archive) {
        try {
            // Crea il file output stream
            FileOutputStream fileOut = new FileOutputStream(FILE_NAME);
            // Crea l'object output stream per serializzare oggetti
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            
            // Salva l'archivio
            out.writeObject(archive);
            
            // Chiudi gli stream
            out.close();
            fileOut.close();
            
            System.out.println("Archivio salvato con successo in " + FILE_NAME);
        } catch (IOException e) {
            System.err.println("Errore durante il salvataggio dell'archivio: " + e.getMessage());
        }
    }
    
    /**
     * Carica l'archivio di canzoni da file
     * @return L'archivio caricato o un nuovo archivio vuoto se si è verificato un errore
     */
    public static Archive load() {
        Archive archive = null;
        
        try {
            // Controlla se il file esiste
            File file = new File(FILE_NAME);
            if (!file.exists()) {
                System.out.println("File di archivio non trovato. Creazione di un nuovo archivio vuoto.");
                return new Archive();
            }
            
            // Crea il file input stream
            FileInputStream fileIn = new FileInputStream(FILE_NAME);
            // Crea l'object input stream per deserializzare oggetti
            ObjectInputStream in = new ObjectInputStream(fileIn);
            
            // Carica l'archivio
            archive = (Archive) in.readObject();
            
            // Chiudi gli stream
            in.close();
            fileIn.close();
            
            System.out.println("Archivio caricato con successo da " + FILE_NAME);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Errore durante il caricamento dell'archivio: " + e.getMessage());
            archive = new Archive(); // Crea un nuovo archivio vuoto in caso di errore
        }
        
        return archive;
    }
}