/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package songarchive;

import control.Logic;
import java.util.ArrayList;
import model.Archive;
import model.Song;
import model.Time;
import view.MainWin;
import view.MyFrame;

/**
 *
 * @author Tondu
 */
public class SongArchive {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Song s = new Song("ciao", 2001, new Time(34,44));
        Song s1 = new Song("come stai", 3333, new Time(34,44));
        Song s2 = new Song("34535", 234, new Time(23,44));
        Archive songList = new Archive();
        
        songList.add(s);
        songList.add(s1);
        songList.add(s2);
        
        Logic l = new Logic();
        l.start(songList);
        
        
    }
    
}
