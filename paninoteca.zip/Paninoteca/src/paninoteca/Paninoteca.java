/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package paninoteca;
import java.awt.HeadlessException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
/**
 *
 * @author Tondu
 */
public class Paninoteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*Creare una classe che modelli una scheda di un panino, nome, descrizione e costo.
        Creare un pannello che consenta di visualizza l'oggetto.
        Visualizzare il pannello in un frame*/
        
        
        //Frame
        PaninoFrame f1 = new PaninoFrame("Panino", 400, 400);
        Panino p1 = new Panino("Panino Tondu", "Prosciutto crudo pomodori secchi");
        Panino p2 = new Panino("Panino Tondu2", "Prosciutto cotto pomodorini, mozzarella");
        Panino p3 = new Panino("Panino Tondu3", "Salsiccia, Gorgonzola");
        p1.setPrice(7.0);
        p2.setPrice(6);
        p3.setPrice(8);
        
        String b = p1.toString();
        String b2 = p2.toString();
        String b3 = p3.toString();
        
        f1.add(new JLabel(b));
        f1.add(new JLabel(b2));
        f1.add(new JLabel(b3));
        

    }
    
}
