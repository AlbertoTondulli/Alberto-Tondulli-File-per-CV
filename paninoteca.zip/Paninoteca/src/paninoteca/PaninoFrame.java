/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paninoteca;

import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.JFrame;

/**
 *
 * @author Tondu
 */
public class PaninoFrame extends MyFrame{

    public PaninoFrame(String title, int height, int weight) throws HeadlessException {
        super(title, height, weight);
    }

    
        
    }
    

