/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paninoteca;

import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.JFrame;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author Tondu
 */
abstract public class MyFrame extends JFrame{
    
    public MyFrame(String title, int height, int weight) throws HeadlessException{
        super(title);
        setSize(height, weight);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3,1));
    
    }
    
}
