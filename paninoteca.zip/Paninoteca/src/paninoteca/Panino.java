/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paninoteca;

/**
 *
 * @author Tondu
 */
public class Panino {
    protected final String name;
    protected final String description;
    protected double price;

    public Panino(String name, String description) {
        this.name = name;
        this.description = description;
    }

    
    boolean setPrice(double price){
        if(price < 0){
            return false;
        }else{
            this.price = price;
            return true;
        }
    }
    
    @Override
    public String toString() {
        return "Panino{" + "name=" + name + ", description=" + description + ", costo=" + price + '}';
    }

    
}
