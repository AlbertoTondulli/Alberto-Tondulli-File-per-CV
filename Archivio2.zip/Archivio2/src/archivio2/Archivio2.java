/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package archivio2;

import control.Logic;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Archive;
import model.Song;
import model.SongTime;
import view.ArchiveFrame;

/**
 *
 * @author gabriel
 */
public class Archivio2 {
    private final static String FILE_NAME = "file1";
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        // TODO code application logic here
        
        //object
        //Song s = new Song("prova",2006, new SongTime(1,2));
        
        //archive
        Archive a = new Archive();
        //a.add(s);
        a.load("archive.dat");
        
        try {
            a.save("archvie.dat");
        } catch (IOException ex) {
            Logger.getLogger(Archivio2.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
        
        
        
        Logic app = new Logic();
        //view
        app.start(a);
        
        
    }
    
}
