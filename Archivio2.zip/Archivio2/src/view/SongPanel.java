/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.Song;
import model.SongTime;

/**
 *
 * @author gabriel
 */
public class SongPanel extends JPanel{
    
     private Song s;

    private final JTextField titleField;
    private final JTextField yearField;
    private final JTextField minuteField;
    private final JTextField secondField;
    
    public SongPanel() {
        
        this.setLayout(new GridLayout(4,2));
        
        titleField = new JTextField(); 
        yearField = new JTextField(); 
        minuteField = new JTextField(); 
        secondField = new JTextField(); 

        this.add(new JLabel("titolo:" ));
        this.add(titleField);
        
        this.add(new JLabel("anno:" ));
        this.add(yearField);
        
        this.add(new JLabel("minuti:" ));
        this.add(minuteField);
        
        this.add(new JLabel("secondi:" ));
        this.add(secondField);
    }
    
    public void setData(Song s){
        this.s = s;
        this.titleField.setText(this.s.getTitle());
        this.yearField.setText("" + this.s.getYear());
        this.minuteField.setText("" + this.s.getTime().getMin());
        this.secondField.setText("" + this.s.getTime().getSec());
        
    }
    
    public Song getData(){
        int min = Integer.parseInt(this.minuteField.getText());
        int sec = Integer.parseInt(this.secondField.getText());
        int year = Integer.parseInt(this.yearField.getText());
        Song out = new Song(this.titleField.getText(),
                            year,
                            new SongTime(min,sec));
        
        return out;
    }
    
}
