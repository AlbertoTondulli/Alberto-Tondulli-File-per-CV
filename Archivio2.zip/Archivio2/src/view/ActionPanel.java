/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import control.Logic;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author gabriel
 */
public class ActionPanel extends JPanel{
    
    

    public ActionPanel(ActionListener al) {
        this.setLayout(new FlowLayout());
        this.newButton("<<", Logic.PREV, al);
        this.newButton("NUOVO", Logic.NEW, al);
        this.newButton(">>", Logic.NEXT, al);                
    }
    
    private JButton newButton(String txt,String cmq, ActionListener al){
        JButton out= new JButton(txt);
        out.addActionListener(al);
        out.setActionCommand(cmq);
        this.add(out);
        return out;
    }
}
