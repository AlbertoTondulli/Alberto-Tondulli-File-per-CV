/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import model.Song;

/**
 *
 * @author gabriel
 */
public class ArchiveFrame extends JFrame {
    
    private final SongPanel songPanel;
    
    public ArchiveFrame(ActionListener al){
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.setSize(300, 150);
        
        
       
        songPanel = new SongPanel();               
        
        this.add(songPanel,BorderLayout.CENTER);
        this.add(new ActionPanel(al),BorderLayout.SOUTH);
    }
    
    public void setData(Song s) {
        songPanel.setData(s);
    }

    public Song getData() {
        return songPanel.getData();
    }
    
    
        
}
  