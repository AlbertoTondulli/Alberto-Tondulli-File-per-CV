/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Archive;
import model.Song;
import view.ArchiveFrame;

/**
 *
 * @author gabriel
 */
public class Logic implements ActionListener {
    public static final String NEW = "new";
    public static final String PREV = "prev";
    public static final String NEXT = "next";
    
    private int cursor;
    private Archive archive;
    private ArchiveFrame win;
    
    public Logic() {
        
    }
   
    public void start(Archive archive) {
        this.archive = archive;
        this.win = new ArchiveFrame(this);
        this.cursor = 0;
        this.updateWin();
        
        win.setVisible(true);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String cmq = e.getActionCommand();
        
        switch(cmq){
            case "":
                break;
            case Logic.NEW:
                System.out.println("nuovo");                
                Song toAppend = win.getData();                
                this.archive.add(toAppend);                                
                this.cursor = this.archive.size()-1;
                this.updateWin();
                break;
                
            case Logic.PREV:              
              if(this.cursor>0){
                  this.cursor--;
                  this.updateWin();
              } else {
                  System.err.println("Inizio dell'archivio");
              }
              break;
              
            case Logic.NEXT:
              System.out.println("successivo");
              if((this.cursor+1)<this.archive.size()){
                  this.cursor++;
                  this.updateWin();
              } else{
                  System.err.println("Fine dell'archivio");
              }
              break;
        }
    }
    private void updateWin(){
        win.setData(this.archive.get(cursor));
    }
}
