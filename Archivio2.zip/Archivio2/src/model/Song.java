/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author gabriel
 */
public class Song implements Serializable{
    private final String title;
    private final int year;
    private final SongTime time;

    public Song(String title, int Year, SongTime time) {
        this.title = title;
        this.year = Year;
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public SongTime getTime() {
        return time;
    }
    
    
    
}
