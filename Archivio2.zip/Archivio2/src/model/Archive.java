/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabriel
 */
public class Archive extends ArrayList<Song> implements Serializable{
   public void load(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException {
       
       FileInputStream f;
       
           f = new FileInputStream("archive.dat");
           ObjectInputStream obj = new ObjectInputStream(f);
           Archive newArchive = (Archive) obj.readObject();
           for(int i = 0; i< newArchive.size(); i++){
               this.add(newArchive.get(i));
           }
       
   }
   
   
   public void save(String fileName) throws FileNotFoundException, IOException {
       
           FileOutputStream f = new FileOutputStream("archive.dat");
           ObjectOutputStream obj = new ObjectOutputStream(f);
           obj.writeObject(this);
           obj.close();
       
   }
}
