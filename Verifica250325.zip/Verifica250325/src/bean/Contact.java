/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

import Exception.*;

/**
 * Represents a contact with fields for name, surname, cell phone number, and address.
 */
public class Contact {
    private final String name; // Immutable field for the contact's first name
    private final String surname; // Immutable field for the contact's last name
    private String cell; // Mutable field for the contact's cell phone number
    private Address address; // Mutable field for the contact's address

    /**
     * Constructor to initialize a Contact object with name and surname.
     *
     * @param name    The first name of the contact.
     * @param surname The last name of the contact.
     */
    public Contact(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    /**
     * Retrieves the first name of the contact.
     *
     * @return The first name of the contact.
     */
    public String getName() {
        return name;
    }

    /**
     * Retrieves the last name of the contact.
     *
     * @return The last name of the contact.
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Retrieves the cell phone number of the contact.
     *
     * @return The cell phone number of the contact.
     */
    public String getCell() {
        return cell;
    }

    /**
     * Sets the cell phone number of the contact.Returns error codes based on the validity of the input.
     *
     * @param cell The new cell phone number for the contact.
     
     * @throws Exception.EmptyValue if the cell number is valid, 1 if the parameter is empty,
     *         Exception.WrongNumber if it contains non-numeric characters.
     */
    public void setCell(String cell) throws MyException {
        if (cell == null || cell.isEmpty()) {
            // Error code 1: the parameter is empty
            throw new EmptyValue();
        }
        if (!cell.matches("\\d+")) {
            // Error code 2: the parameter contains non-numeric characters
            throw new WrongNumber();
        }
        this.cell = cell;
    
    }

    /**
     * Retrieves the address of the contact.
     *
     * @return The address of the contact as an Address object.
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the address of the contact.
     *
     * @param address The new address for the contact as an Address object.
     */
    public void setAddress(Address address) {
        this.address = address;
    }

    /**
     * Returns a string representation of the contact object.
     *
     * @return A string containing the contact's details.
     */
    @Override
    public String toString() {
        return "Contact [name=" + name + ", surname=" + surname + 
               ", cell=" + cell + ", address=" + address + "]";
    }
}
