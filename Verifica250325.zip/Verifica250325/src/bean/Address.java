/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

/**
 * Represents an address with street, number, and city fields.
 */
public class Address {
    private final String street;
    private final int number;
    private final String city;

    /**
     * Constructor with parameters to initialize an Address object.
     *
     * @param street The street name of the address.
     * @param number The number of the address.
     * @param city   The city of the address.
     */
    public Address(String street, int number, String city) {
        this.street = street;
        this.number = number;
        this.city = city;
    }

    /**
     * Retrieves the street name of the address.
     *
     * @return The street name.
     */
    public String getStreet() {
        return street;
    }

    /**
     * Retrieves the number of the address.
     *
     * @return The number of the address.
     */
    public int getNumber() {
        return number;
    }

    /**
     * Retrieves the city of the address.
     *
     * @return The city of the address.
     */
    public String getCity() {
        return city;
    }

    /**
     * Returns a string representation of the address object.
     *
     * @return A string containing the address details.
     */
    @Override
    public String toString() {
        return street + " " + number + ", " + city;
    }
}

