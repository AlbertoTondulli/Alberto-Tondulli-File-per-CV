/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exception;

/**
 *
 * @author fdipalma
 */
public class WrongNumber extends MyException{

    public WrongNumber() {
        super("Valore non corretto");
    }
    
}
