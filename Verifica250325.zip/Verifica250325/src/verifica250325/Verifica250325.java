/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package verifica250325;

import Exception.MyException;
import bean.Address;
import bean.Contact;
import java.util.logging.Level;
import java.util.logging.Logger;
import view.MyFrame;

/**
 *
 * @author fdipalma
 */
public class Verifica250325 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Address a = new Address("verdi", 19, "Pavia");
        System.out.println(a);
        Contact c = new Contact("Itis", "Cardano");
        try {
            c.setCell("0357");
        } catch (MyException ex) {
            System.out.println(ex.getMessage());
        }
        c.setAddress(a);
        System.out.println(c);
        
        try {
            c.setCell("");
        } catch (MyException ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println(c);
        
        try {
            c.setCell("ciao");
        } catch (MyException ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println(c);
        
        MyFrame win = new MyFrame(c);
        win.setVisible(true);
    }
    
}
