/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import bean.Contact;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author fdipalma
 */
public class ContactPanel extends JPanel{
    // data field
    Contact data;
    // graphical object data related
    JTextField jname,jsurname, jcell, jaddress;

    public ContactPanel(Contact data) {
        super();
        this.setLayout(new GridLayout(0,2));
        // create graphical object        
        
        this.jname = this.addJTextField("Nome");
        
        this.jsurname = this.addJTextField("Cognome");
        this.jcell = this.addJTextField("Cell");
        this.jaddress = this.addJTextField("Indirizzo");
        
        this.updateData(data);
    }

    public void updateData(Contact data) {
        // set data
        this.data = data;
        
        // udate graphical object data related info
        this.jname.setText(this.data.getName());
        this.jsurname.setText(this.data.getSurname());
        this.jcell.setText(this.data.getCell());
        this.jaddress.setText(this.data.getAddress().toString());
    }
    
    private JTextField addJTextField(String labelText){
        JTextField out;
        
        this.add(new JLabel(labelText));
        out = new JTextField(50);
        this.add(out);
        
        return out;
        
    }
}
