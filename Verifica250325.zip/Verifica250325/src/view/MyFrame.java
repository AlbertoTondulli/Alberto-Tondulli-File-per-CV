/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import bean.Contact;
import java.awt.BorderLayout;
import java.awt.HeadlessException;
import javax.swing.JFrame;

/**
 *
 * @author fdipalma
 */
public class MyFrame extends JFrame{
    
    private ContactPanel dp;
    
    public MyFrame(Contact c) {
        super("Avanzato");
        this.setSize(300,150);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.dp = new ContactPanel(c);
        this.add(dp,BorderLayout.CENTER);
        this.add(new SearchPanel(),BorderLayout.NORTH);
        
    }
    
    
}
