/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author fdipalma
 */
public class SearchPanel extends JPanel{

    public SearchPanel() {
        super();
        this.setLayout(new FlowLayout());
        this.add(new JLabel("Nome:"));
        this.add(new JTextField(10));
        this.add(new JButton("Cerca"));
    }
    
    
}
